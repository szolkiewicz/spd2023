import copy 

def DP(_J):

    J = _J.copy()
    n = len(J)
    mask = (1 << n)

    memory = [-1 for _ in range(mask)]
    memory[0] = 0
    for D in range(1,mask):
        TimeSum = 0
        for i in range(0,n):
            if D & (1<<i):
                TimeSum += J[i][0]
        MinPenalty = float('inf')
        for i in range(0,n):
            if D & (1<<i):
                Penalty = max(TimeSum - J[i][2] ,0)* J[i][1] + memory[D ^ (1<<i)]
                MinPenalty = min(MinPenalty, Penalty)
        memory[D] = MinPenalty
    return memory[mask-1]

def DPmod(_J):

    J = _J.copy()
    n = len(J)
    depth = 0
    mask = (1 << n)

    memory = [-1 for _ in range(mask)]
    memory[0] = 0

    tasks = [0 for _ in range(mask)]
    for D in range(1,mask):
        TimeSum = 0
        depth = 0
        for i in range(0,n):
            if D & (1<<i):
                TimeSum += J[i][0]
                depth += 1

        MinPenalty = float('inf')
        for i in range(0,n):
            if D & (1<<i):
                Penalty = max(TimeSum - J[i][2] ,0)* J[i][1] + memory[D ^ (1<<i)]
                if MinPenalty > Penalty:
                    MinPenalty = Penalty
                    task = i + 1
                    

        memory[D] = MinPenalty
        tasks[D] = task
    print(tasks)
    return memory[mask-1]

